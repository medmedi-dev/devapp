import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { isAdmin } from '../lib/firebase/admin';
import { ActionButton } from '../components/ActionButton';
import { auth } from '../lib/firebase';
import { signOut } from 'firebase/auth';

export function AdminLogin() {
  const [error, setError] = useState('');
  const { signIn } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');

    const email = 'admin@gmail.com';
    const password = 'admin@gmail.com';

    try {
      const { user } = await signIn(email, password);
      const adminStatus = await isAdmin(user.uid);
      
      if (adminStatus) {
        navigate('/admin/dashboard');
      } else {
        setError('Unauthorized access');
        await signOut(auth);
      }
    } catch (err) {
      setError('Invalid credentials');
    }
  };

  return (
    <div className="min-h-screen bg-[#121010] flex items-center justify-center px-4">
      <div className="max-w-md w-full space-y-8 bg-[#2C2317] p-8 rounded-xl">
        <div>
          <h2 className="text-center text-3xl font-bold text-white">Admin Login</h2>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <ActionButton type="submit" variant="primary" className="w-full">
            Login as Admin
          </ActionButton>
        </form>
      </div>
    </div>
  );
}