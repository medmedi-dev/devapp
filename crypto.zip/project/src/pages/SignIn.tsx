import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { AuthForm } from '../components/AuthForm';
import { useAuth } from '../contexts/AuthContext';

interface SignInFormData {
  email: string;
  password: string;
}

export function SignIn() {
  const [error, setError] = useState('');
  const { signIn } = useAuth();
  const navigate = useNavigate();

  const handleSignIn = async (formData: SignInFormData) => {
    try {
      await signIn(formData.email, formData.password);
      
      // Check if the user is admin and redirect accordingly
      if (formData.email === 'admin@gmail.com') {
        navigate('/admin/dashboard');
      } else {
        navigate('/dashboard');
      }
    } catch (err) {
      setError('Invalid email or password');
    }
  };

  return (
    <div className="min-h-screen bg-[#121010] flex items-center justify-center px-4">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="text-center text-3xl font-extrabold text-white">
            Sign in to Crypture
          </h2>
        </div>
        <AuthForm type="signin" onSubmit={handleSignIn} error={error} />
        <p className="text-center text-sm text-gray-400">
          Don't have an account?{' '}
          <Link to="/signup" className="text-[#B38E3C] hover:text-[#DEB761]">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}