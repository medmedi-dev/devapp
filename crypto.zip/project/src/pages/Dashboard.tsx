import { Users, Wallet, Shield, BookOpen, Globe, HelpCircle, Settings } from 'lucide-react';
import { Header } from '../components/dashboard/Header';
import { StatsCard } from '../components/dashboard/StatsCard';
import { TeamOverview } from '../components/dashboard/TeamOverview';
import { MenuItem } from '../components/dashboard/MenuItems';

export function Dashboard() {
  const menuItems = [
    { icon: <Users />, label: 'My Team' },
    { icon: <Wallet />, label: 'Investment Plans' },
    { icon: <Shield />, label: 'Security Center' },
    { icon: <BookOpen />, label: 'Tutorial' },
    { icon: <Globe />, label: 'Language', rightText: 'English →' },
    { icon: <HelpCircle />, label: 'Help Center' },
    { icon: <Settings />, label: 'Settings', to: '/settings' },
  ];

  return (
    <div className="min-h-screen bg-[#121010] text-white">
      <Header />
      
      <div className="p-4">
        <StatsCard />
      </div>

      <div className="p-4">
        <TeamOverview />
      </div>

      <div className="p-4 space-y-4">
        {menuItems.map((item) => (
          <MenuItem
            key={item.label}
            icon={item.icon}
            label={item.label}
            rightText={item.rightText}
            to={item.to}
          />
        ))}
      </div>
    </div>
  );
}