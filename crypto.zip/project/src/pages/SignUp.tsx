import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { FirebaseError } from 'firebase/app';
import { AuthForm } from '../components/AuthForm';
import { useAuth } from '../contexts/AuthContext';
import { createUserProfile } from '../lib/firebase/db';

interface SignUpFormData {
  fullName: string;
  username: string;
  email: string;
  password: string;
}

const getErrorMessage = (error: FirebaseError) => {
  switch (error.code) {
    case 'auth/email-already-in-use':
      return 'This email is already registered. Please use a different email or sign in.';
    case 'auth/invalid-email':
      return 'Invalid email address. Please check and try again.';
    case 'auth/weak-password':
      return 'Password is too weak. Please use at least 6 characters.';
    case 'auth/network-request-failed':
      return 'Network error. Please check your connection and try again.';
    case 'auth/operation-not-allowed':
      return 'Email/password registration is not enabled. Please contact support.';
    default:
      return error.message || 'An error occurred during registration. Please try again.';
  }
};

export function SignUp() {
  const [error, setError] = useState('');
  const { signUp } = useAuth();
  const navigate = useNavigate();

  const handleSignUp = async (formData: SignUpFormData) => {
    try {
      // Validate password length
      if (formData.password.length < 6) {
        setError('Password must be at least 6 characters long');
        return;
      }

      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        setError('Please enter a valid email address');
        return;
      }

      const { user } = await signUp(formData.email, formData.password);
      
      await createUserProfile(user.uid, {
        fullName: formData.fullName,
        username: formData.username,
        email: formData.email,
      });
      
      navigate('/dashboard');
    } catch (err) {
      console.error('SignUp error:', err);
      
      if (err instanceof FirebaseError) {
        setError(getErrorMessage(err));
      } else if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred. Please try again.');
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#121010] flex items-center justify-center px-4">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="text-center text-3xl font-extrabold text-white">
            Create your account
          </h2>
        </div>
        <AuthForm type="signup" onSubmit={handleSignUp} error={error} />
        <p className="text-center text-sm text-gray-400">
          Already have an account?{' '}
          <Link to="/signin" className="text-[#B38E3C] hover:text-[#DEB761]">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}