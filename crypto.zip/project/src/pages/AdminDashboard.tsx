import { useState, useEffect } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { WithdrawalRequestsTable } from '../components/admin/WithdrawalRequestsTable';
import { DashboardCard } from '../components/DashboardCard';
import { Users, DollarSign, Award, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { DepositsTable } from '../components/admin/DepositsTable';
import type { UserProfile } from '../types/user';

export function AdminDashboard() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const { logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Real-time listener for users collection
    const unsubscribe = onSnapshot(collection(db, 'users'), (snapshot) => {
      const usersData = snapshot.docs.map(doc => ({
        ...doc.data(),
        uid: doc.id,
      })) as UserProfile[];
      setUsers(usersData);
    });

    return () => unsubscribe();
  }, []);

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/signin');
    } catch (error) {
      console.error('Failed to log out:', error);
    }
  };

  const totalBalance = users.reduce((sum, user) => sum + (user.balance || 0), 0);
  const totalVipUsers = users.filter(user => user.vipLevel > 1).length;

  return (
    <div className="min-h-screen bg-[#121010] text-white p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <button
            onClick={handleLogout}
            className="text-[#B38E3C] hover:text-[#DEB761] flex items-center"
          >
            <LogOut className="w-5 h-5 mr-2" /> Logout
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <DashboardCard
            title="Total Users"
            value={users.length}
            icon={<Users size={24} />}
          />
          <DashboardCard
            title="Total Balance"
            value={`${totalBalance.toFixed(2)} USDT`}
            icon={<DollarSign size={24} />}
          />
          <DashboardCard
            title="VIP Users"
            value={totalVipUsers}
            icon={<Award size={24} />}
          />
        </div>

        {/* New User Details Section */}
        <div className="bg-gradient-to-br from-[#2C2317] to-[#1A1512] rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4">User Details</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left bg-[#1A1512]">
                  <th className="p-4">User ID</th>
                  <th className="p-4">Email</th>
                  <th className="p-4">Full Name</th>
                  <th className="p-4">Balance</th>
                  <th className="p-4">VIP Level</th>
                  <th className="p-4">Join Date</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user.uid} className="border-t border-[#B38E3C]/20">
                    <td className="p-4">{user.uid.slice(0, 8)}</td>
                    <td className="p-4">{user.email}</td>
                    <td className="p-4">{user.fullName}</td>
                    <td className="p-4">{user.balance?.toFixed(2)} USDT</td>
                    <td className="p-4">
                      <span className={`px-2 py-1 rounded text-sm ${
                        user.vipLevel === 1 ? 'bg-gray-500/20 text-gray-300' :
                        user.vipLevel === 2 ? 'bg-[#B38E3C]/20 text-[#B38E3C]' :
                        'bg-[#DEB761]/20 text-[#DEB761]'
                      }`}>
                        VIP {user.vipLevel}
                      </span>
                    </td>
                    <td className="p-4">
                      {user.createdAt?.toDate?.()?.toLocaleDateString() || 'N/A'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#2C2317] to-[#1A1512] rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4">Deposit Requests</h2>
          <DepositsTable />
        </div>

        <div className="bg-gradient-to-br from-[#2C2317] to-[#1A1512] rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4">Withdrawal Requests</h2>
          <WithdrawalRequestsTable />
        </div>
      </div>
    </div>
  );
}