import { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { ProfileSection } from '../components/settings/ProfileSection';
import { SecuritySection } from '../components/settings/SecuritySection';
import { MembershipSection } from '../components/settings/MembershipSection';
import { AccountActions } from '../components/settings/AccountActions';

type SettingsTab = 'profile' | 'security' | 'membership';

export function Settings() {
  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');
  const navigate = useNavigate();

  const tabs: { id: SettingsTab; label: string }[] = [
    { id: 'profile', label: 'Profile' },
    { id: 'security', label: 'Security' },
    { id: 'membership', label: 'Membership' },
  ];

  return (
    <div className="min-h-screen bg-[#121010] text-white p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 text-[#B38E3C] hover:text-[#DEB761] transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold">Account Settings</h1>
        </div>
        
        <div className="flex space-x-4 border-b border-[#B38E3C]/20">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 font-medium ${
                activeTab === tab.id
                  ? 'text-[#B38E3C] border-b-2 border-[#B38E3C]'
                  : 'text-gray-400 hover:text-[#B38E3C]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="py-6">
          {activeTab === 'profile' && <ProfileSection />}
          {activeTab === 'security' && <SecuritySection />}
          {activeTab === 'membership' && <MembershipSection />}
        </div>

        <AccountActions />
      </div>
    </div>
  );
}