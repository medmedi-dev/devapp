import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export function AdminRoute({ children }: { children: React.ReactNode }) {
  const { currentUser, loading } = useAuth();

  if (loading) {
    return <div>Loading...</div>;
  }

  // Check if user is logged in and has admin email
  if (currentUser && currentUser.email === 'admin@gmail.com') {
    return <>{children}</>;
  }

  // Redirect to sign in if not authenticated or not admin
  return <Navigate to="/signin" />;
}