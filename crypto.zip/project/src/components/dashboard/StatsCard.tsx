import { useState, useEffect } from 'react';
import { ArrowDownToLine, ArrowUpToLine, LayoutList } from 'lucide-react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { ActionButton } from '../ActionButton';
import { DepositModal } from '../modals/DepositModal';
import { WithdrawModal } from '../modals/WithdrawModal';
import { TransactionHistory } from '../modals/TransactionHistory';
import { useAuth } from '../../contexts/AuthContext';
import type { UserProfile } from '../../types/user';

export function StatsCard() {
  const [showDeposit, setShowDeposit] = useState(false);
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [userStats, setUserStats] = useState<UserProfile | null>(null);
  const { currentUser } = useAuth();

  useEffect(() => {
    if (!currentUser) return;

    // Set up real-time listener for user stats
    const unsubscribe = onSnapshot(
      doc(db, 'users', currentUser.uid),
      (doc) => {
        if (doc.exists()) {
          setUserStats(doc.data() as UserProfile);
        }
      }
    );

    return () => unsubscribe();
  }, [currentUser]);

  return (
    <>
      <div className="bg-gradient-to-br from-[#2C2317] to-[#1A1512] rounded-xl p-6 border border-[#B38E3C]/20">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-[#B38E3C] text-sm">Total balance</p>
            <p className="text-2xl font-bold">{userStats?.balance?.toFixed(2) || '0.00'} USDT</p>
          </div>
          <div>
            <p className="text-[#B38E3C] text-sm">Total revenue</p>
            <p className="text-2xl font-bold">{userStats?.totalRevenue?.toFixed(2) || '0.00'} USDT</p>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-4">
          <div>
            <p className="text-[#B38E3C] text-sm">Today's Earnings</p>
            <p className="text-xl font-bold">{userStats?.todaysEarnings?.toFixed(2) || '0.00'} USDT</p>
          </div>
          <div>
            <p className="text-[#B38E3C] text-sm">Yesterday's earnings</p>
            <p className="text-xl font-bold">{userStats?.yesterdaysEarnings?.toFixed(2) || '0.00'} USDT</p>
          </div>
          <div>
            <p className="text-[#B38E3C] text-sm">Commission today</p>
            <p className="text-xl font-bold">{userStats?.commissionToday?.toFixed(2) || '0.00'} USDT</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mt-6">
          <ActionButton 
            variant="primary" 
            icon={<ArrowDownToLine size={20} />}
            onClick={() => setShowDeposit(true)}
          >
            Deposit
          </ActionButton>
          <ActionButton 
            variant="secondary" 
            icon={<ArrowUpToLine size={20} />}
            onClick={() => setShowWithdraw(true)}
          >
            Withdraw
          </ActionButton>
          <ActionButton 
            variant="secondary" 
            icon={<LayoutList size={20} />}
            onClick={() => setShowHistory(true)}
          >
            History
          </ActionButton>
        </div>
      </div>

      <DepositModal 
        isOpen={showDeposit} 
        onClose={() => setShowDeposit(false)} 
      />
      <WithdrawModal 
        isOpen={showWithdraw} 
        onClose={() => setShowWithdraw(false)}
        maxAmount={userStats?.balance || 0}
      />
      <TransactionHistory 
        isOpen={showHistory} 
        onClose={() => setShowHistory(false)} 
      />
    </>
  );
}