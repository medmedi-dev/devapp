export function TeamOverview() {
  return (
    <div className="bg-gradient-to-br from-[#2C2317] to-[#1A1512] rounded-xl p-6 border border-[#B38E3C]/20">
      <h2 className="text-lg font-semibold mb-4">Team Overview</h2>
      <div className="grid grid-cols-3 gap-4">
        {[1, 2, 3].map((level) => (
          <div key={level}>
            <p className="text-[#B38E3C]">Level {level}</p>
            <p className="text-center">0(0)</p>
          </div>
        ))}
      </div>
    </div>
  );
}