import { useNavigate } from 'react-router-dom';

interface MenuItemProps {
  icon: React.ReactNode;
  label: string;
  rightText?: string;
  to?: string;
}

export function MenuItem({ icon, label, rightText = '→', to }: MenuItemProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    if (to) {
      navigate(to);
    }
  };

  return (
    <button 
      onClick={handleClick}
      className="w-full flex items-center justify-between p-4 bg-gradient-to-br from-[#2C2317] to-[#1A1512] rounded-lg"
    >
      <div className="flex items-center gap-3">
        <span className="text-[#B38E3C]">{icon}</span>
        <span>{label}</span>
      </div>
      <span className="text-[#B38E3C]">{rightText}</span>
    </button>
  );
}