import { Settings } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { NotificationBell } from './NotificationBell';

export function Header() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const username = currentUser?.email?.split('@')[0] || 'User';

  return (
    <div className="bg-[#2C2317] p-4 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-[#B38E3C] rounded-full flex items-center justify-center">
          <span className="text-xl font-bold">{username[0].toUpperCase()}</span>
        </div>
        <div>
          <h1 className="text-xl">Hi, {username}</h1>
          <span className="text-[#DEB761]">VIP1</span>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="text-[#B38E3C]">
          ID: {currentUser?.uid.slice(0, 8)}
        </div>
        <NotificationBell />
        <button 
          onClick={() => navigate('/settings')}
          className="p-2 text-[#B38E3C] hover:text-[#DEB761] transition-colors"
        >
          <Settings size={24} />
        </button>
      </div>
    </div>
  );
}