import { useEffect, useState } from 'react';
import { Check, X } from 'lucide-react';
import { collection, query, where, onSnapshot, updateDoc, doc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { createNotification, updateUserBalance } from '../../lib/firebase/db';
import { ActionButton } from '../ActionButton';
import type { Transaction } from '../../types/user';

export function DepositsTable() {
  const [deposits, setDeposits] = useState<Transaction[]>([]);
  const [processing, setProcessing] = useState<string | null>(null);

  useEffect(() => {
    const q = query(
      collection(db, 'transactions'),
      where('type', '==', 'deposit'),
      where('status', '==', 'pending')
    );

    return onSnapshot(q, (snapshot) => {
      const deposits = snapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id,
      })) as Transaction[];
      setDeposits(deposits);
    });
  }, []);

  const handleStatusUpdate = async (deposit: Transaction, status: 'approved' | 'rejected') => {
    if (!deposit.id || processing) return;

    setProcessing(deposit.id);
    try {
      const transactionRef = doc(db, 'transactions', deposit.id);
      await updateDoc(transactionRef, { 
        status,
        processedAt: new Date()
      });

      if (status === 'approved') {
        // Update user balance first
        await updateUserBalance(deposit.userId, deposit.amount);

        // Then create notification
        await createNotification({
          userId: deposit.userId,
          type: 'transaction',
          title: 'Deposit Approved',
          message: `Your deposit of ${deposit.amount} USDT has been approved`,
          transactionId: deposit.id,
          timestamp: new Date(),
        });
      } else {
        await createNotification({
          userId: deposit.userId,
          type: 'transaction',
          title: 'Deposit Rejected',
          message: `Your deposit of ${deposit.amount} USDT has been rejected`,
          transactionId: deposit.id,
          timestamp: new Date(),
        });
      }
    } catch (error) {
      console.error('Error updating deposit status:', error);
    } finally {
      setProcessing(null);
    }
  };

  const formatTimestamp = (timestamp: any) => {
    if (!timestamp) return '';
    try {
      const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
      return date.toLocaleString();
    } catch (error) {
      return 'Invalid date';
    }
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="text-left bg-[#1A1512]">
            <th className="p-4">User ID</th>
            <th className="p-4">Amount</th>
            <th className="p-4">Date</th>
            <th className="p-4">Status</th>
            <th className="p-4">Actions</th>
          </tr>
        </thead>
        <tbody>
          {deposits.map(deposit => (
            <tr key={deposit.id} className="border-t border-[#B38E3C]/20">
              <td className="p-4">{deposit.userId.slice(0, 8)}</td>
              <td className="p-4">{deposit.amount.toFixed(2)} USDT</td>
              <td className="p-4">{formatTimestamp(deposit.timestamp)}</td>
              <td className="p-4">
                <span className="px-2 py-1 rounded text-sm bg-yellow-500/20 text-yellow-500">
                  {deposit.status}
                </span>
              </td>
              <td className="p-4">
                <div className="flex gap-2">
                  <ActionButton
                    variant="primary"
                    onClick={() => handleStatusUpdate(deposit, 'approved')}
                    disabled={processing === deposit.id}
                  >
                    <Check size={16} />
                  </ActionButton>
                  <ActionButton
                    variant="secondary"
                    onClick={() => handleStatusUpdate(deposit, 'rejected')}
                    disabled={processing === deposit.id}
                    className="!bg-red-900/20 text-red-500 hover:!bg-red-900/30"
                  >
                    <X size={16} />
                  </ActionButton>
                </div>
              </td>
            </tr>
          ))}
          {deposits.length === 0 && (
            <tr>
              <td colSpan={5} className="text-center py-8 text-gray-400">
                No pending deposits
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}