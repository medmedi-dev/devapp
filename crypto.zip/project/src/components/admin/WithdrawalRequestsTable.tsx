import { useState, useEffect } from 'react';
import { Check, X } from 'lucide-react';
import { ActionButton } from '../ActionButton';
import { subscribeToAllWithdrawalRequests, updateWithdrawalStatus } from '../../lib/firebase/withdrawals';
import type { WithdrawalRequest } from '../../types/withdrawal';

export function WithdrawalRequestsTable() {
  const [requests, setRequests] = useState<WithdrawalRequest[]>([]);
  const [processing, setProcessing] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeToAllWithdrawalRequests(setRequests);
    return () => unsubscribe();
  }, []);

  const handleStatusUpdate = async (requestId: string, status: 'approved' | 'rejected') => {
    setProcessing(requestId);
    try {
      await updateWithdrawalStatus(requestId, status);
    } finally {
      setProcessing(null);
    }
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="bg-[#2C2317]">
            <th className="px-4 py-2 text-left">User</th>
            <th className="px-4 py-2 text-left">Amount</th>
            <th className="px-4 py-2 text-left">Wallet</th>
            <th className="px-4 py-2 text-left">Status</th>
            <th className="px-4 py-2 text-left">Date</th>
            <th className="px-4 py-2 text-left">Actions</th>
          </tr>
        </thead>
        <tbody>
          {requests.map((request) => (
            <tr key={request.id} className="border-b border-[#2C2317]">
              <td className="px-4 py-2">{request.userId}</td>
              <td className="px-4 py-2">{request.amount} USDT</td>
              <td className="px-4 py-2 font-mono text-sm">{request.walletAddress}</td>
              <td className="px-4 py-2">
                <span className={`px-2 py-1 rounded text-sm ${
                  request.status === 'pending' ? 'bg-yellow-500/20 text-yellow-500' :
                  request.status === 'approved' ? 'bg-green-500/20 text-green-500' :
                  'bg-red-500/20 text-red-500'
                }`}>
                  {request.status}
                </span>
              </td>
              <td className="px-4 py-2">
                {new Date(request.createdAt).toLocaleDateString()}
              </td>
              <td className="px-4 py-2">
                {request.status === 'pending' && (
                  <div className="flex gap-2">
                    <ActionButton
                      variant="primary"
                      onClick={() => handleStatusUpdate(request.id, 'approved')}
                      disabled={processing === request.id}
                    >
                      <Check size={16} />
                    </ActionButton>
                    <ActionButton
                      variant="secondary"
                      onClick={() => handleStatusUpdate(request.id, 'rejected')}
                      disabled={processing === request.id}
                      className="!bg-red-900/20 text-red-500 hover:!bg-red-900/30"
                    >
                      <X size={16} />
                    </ActionButton>
                  </div>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}