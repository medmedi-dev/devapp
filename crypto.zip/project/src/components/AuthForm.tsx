import React from 'react';
import { ActionButton } from './ActionButton';

interface AuthFormProps {
  type: 'signin' | 'signup';
  onSubmit: (data: any) => Promise<void>;
  error?: string;
}

export function AuthForm({ type, onSubmit, error }: AuthFormProps) {
  const [formData, setFormData] = React.useState({
    fullName: '',
    username: '',
    email: '',
    password: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Pass the email and password for signin, full object for signup
      if (type === 'signin') {
        await onSubmit({ email: formData.email, password: formData.password });
      } else {
        await onSubmit(formData);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.id]: e.target.value
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      )}
      
      {type === 'signup' && (
        <>
          <div>
            <label htmlFor="fullName" className="block text-sm font-medium text-white">
              Full Name
            </label>
            <input
              type="text"
              id="fullName"
              value={formData.fullName}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md bg-[#2C2317] border-[#B38E3C] text-white"
              required
            />
          </div>
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-white">
              Username
            </label>
            <input
              type="text"
              id="username"
              value={formData.username}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md bg-[#2C2317] border-[#B38E3C] text-white"
              required
            />
          </div>
        </>
      )}

      <div>
        <label htmlFor="email" className="block text-sm font-medium text-white">
          Email
        </label>
        <input
          type="email"
          id="email"
          value={formData.email}
          onChange={handleChange}
          className="mt-1 block w-full rounded-md bg-[#2C2317] border-[#B38E3C] text-white"
          required
        />
      </div>
      <div>
        <label htmlFor="password" className="block text-sm font-medium text-white">
          Password
        </label>
        <input
          type="password"
          id="password"
          value={formData.password}
          onChange={handleChange}
          className="mt-1 block w-full rounded-md bg-[#2C2317] border-[#B38E3C] text-white"
          required
        />
      </div>
      <ActionButton type="submit">
        {type === 'signin' ? 'Sign In' : 'Sign Up'}
      </ActionButton>
    </form>
  );
}