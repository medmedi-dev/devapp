import { useState } from 'react';
import { Modal } from '../modals/Modal';
import { ActionButton } from '../ActionButton';
import { useAuth } from '../../contexts/AuthContext';
import { createTransaction } from '../../lib/firebase/db';

interface VipLevel {
  level: number;
  minDeposit: number;
  maxDeposit: number | null;
  earnings: string;
}

interface UpgradeVipModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLevel: number;
  nextLevel: VipLevel;
}

export function UpgradeVipModal({
  isOpen,
  onClose,
  currentLevel,
  nextLevel,
}: UpgradeVipModalProps) {
  const [amount, setAmount] = useState('');
  const [error, setError] = useState('');
  const { currentUser } = useAuth();

  const handleUpgrade = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    const depositAmount = Number(amount);
    if (depositAmount < nextLevel.minDeposit) {
      setError(`Minimum deposit required: ${nextLevel.minDeposit} USDT`);
      return;
    }

    try {
      await createTransaction({
        userId: currentUser.uid,
        type: 'deposit',
        amount: depositAmount,
        status: 'pending',
        timestamp: new Date(),
      });
      onClose();
    } catch (error) {
      setError('Failed to process upgrade request');
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Upgrade to VIP ${nextLevel.level}`}>
      <form onSubmit={handleUpgrade} className="space-y-4">
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
            {error}
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-white">
            Deposit Amount (USDT)
          </label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="mt-1 block w-full rounded-md bg-[#1A1512] border-[#B38E3C] text-white"
            min={nextLevel.minDeposit}
            max={nextLevel.maxDeposit || undefined}
            step="0.01"
            required
          />
          <p className="mt-1 text-sm text-[#B38E3C]">
            Minimum deposit: {nextLevel.minDeposit} USDT
          </p>
        </div>

        <div className="space-y-2 text-sm">
          <p className="text-[#B38E3C]">Upgrade Benefits:</p>
          <ul className="list-disc list-inside space-y-1 text-gray-300">
            <li>Increased daily earnings rate to {nextLevel.earnings}</li>
            <li>Higher withdrawal limits</li>
            <li>Priority support</li>
          </ul>
        </div>

        <div className="flex gap-4">
          <ActionButton
            type="button"
            variant="secondary"
            className="flex-1"
            onClick={onClose}
          >
            Cancel
          </ActionButton>
          <ActionButton
            type="submit"
            variant="primary"
            className="flex-1"
            disabled={!amount || Number(amount) < nextLevel.minDeposit}
          >
            Upgrade Now
          </ActionButton>
        </div>
      </form>
    </Modal>
  );
}