import { useState } from 'react';
import { Modal } from '../modals/Modal';
import { ActionButton } from '../ActionButton';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { deleteUser } from 'firebase/auth';

export function DeleteAccountModal({ 
  isOpen, 
  onClose 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
}) {
  const [confirmation, setConfirmation] = useState('');
  const [error, setError] = useState('');
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const handleDelete = async () => {
    if (!currentUser) return;
    if (confirmation !== 'DELETE') {
      setError('Please type DELETE to confirm');
      return;
    }

    try {
      await deleteUser(currentUser);
      navigate('/signin');
    } catch (error) {
      setError('Failed to delete account. Please try again.');
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Delete Account">
      <div className="space-y-4">
        <div className="bg-red-100 text-red-700 p-4 rounded-lg">
          <p className="font-medium">Warning: This action cannot be undone</p>
          <p className="text-sm mt-1">
            Your account and all associated data will be permanently deleted.
          </p>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
            {error}
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-white mb-2">
            Type DELETE to confirm
          </label>
          <input
            type="text"
            value={confirmation}
            onChange={(e) => setConfirmation(e.target.value)}
            className="block w-full rounded-md bg-[#2C2317] border-[#B38E3C] text-white"
          />
        </div>

        <div className="flex gap-4 pt-4">
          <ActionButton
            type="button"
            variant="secondary"
            className="flex-1"
            onClick={onClose}
          >
            Cancel
          </ActionButton>
          <ActionButton
            type="button"
            variant="primary"
            className="flex-1 !bg-red-600 hover:!bg-red-700"
            onClick={handleDelete}
            disabled={confirmation !== 'DELETE'}
          >
            Delete Account
          </ActionButton>
        </div>
      </div>
    </Modal>
  );
}