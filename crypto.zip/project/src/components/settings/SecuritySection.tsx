import { useState } from 'react';
import { ActionButton } from '../ActionButton';
import { useAuth } from '../../contexts/AuthContext';
import { auth } from '../../lib/firebase';
import { updatePassword } from 'firebase/auth';

export function SecuritySection() {
  const { currentUser } = useAuth();
  const [passwords, setPasswords] = useState({
    newPassword: '',
    confirmPassword: '',
  });
  const [message, setMessage] = useState({ type: '', text: '' });

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (passwords.newPassword !== passwords.confirmPassword) {
      setMessage({ type: 'error', text: 'Passwords do not match' });
      return;
    }

    try {
      await updatePassword(currentUser, passwords.newPassword);
      setMessage({ type: 'success', text: 'Password updated successfully!' });
      setPasswords({ newPassword: '', confirmPassword: '' });
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to update password' });
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Security Settings</h2>
      
      {message.text && (
        <div className={`p-4 rounded-lg ${
          message.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
        }`}>
          {message.text}
        </div>
      )}

      <form onSubmit={handlePasswordChange} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-white">New Password</label>
          <input
            type="password"
            value={passwords.newPassword}
            onChange={(e) => setPasswords(prev => ({ ...prev, newPassword: e.target.value }))}
            className="mt-1 block w-full rounded-md bg-[#2C2317] border-[#B38E3C] text-white"
            minLength={6}
            required
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-white">Confirm Password</label>
          <input
            type="password"
            value={passwords.confirmPassword}
            onChange={(e) => setPasswords(prev => ({ ...prev, confirmPassword: e.target.value }))}
            className="mt-1 block w-full rounded-md bg-[#2C2317] border-[#B38E3C] text-white"
            minLength={6}
            required
          />
        </div>

        <ActionButton type="submit" variant="primary">
          Update Password
        </ActionButton>
      </form>
    </div>
  );
}