import { LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { ActionButton } from '../ActionButton';
import { useAuth } from '../../contexts/AuthContext';

export function AccountActions() {
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/signin');
    } catch (error) {
      console.error('Failed to log out:', error);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Account Actions</h2>
      
      <div className="bg-gradient-to-br from-[#2C2317] to-[#1A1512] rounded-xl p-6 border border-[#B38E3C]/20">
        <div className="space-y-4">
          <p className="text-gray-400">
            Click the button below to securely log out of your account
          </p>
          
          <ActionButton
            variant="secondary"
            onClick={handleLogout}
            className="w-full !bg-red-900/20 text-red-500 hover:!bg-red-900/30"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Log Out
          </ActionButton>
        </div>
      </div>
    </div>
  );
}