import { useState, useEffect } from 'react';
import { Camera, Trash2 } from 'lucide-react';
import { ActionButton } from '../ActionButton';
import { updateUserProfile, getUserProfile } from '../../lib/firebase/db';
import { useAuth } from '../../contexts/AuthContext';
import { DeleteAccountModal } from './DeleteAccountModal';
import type { UserProfile } from '../../types/user';

export function ProfileSection() {
  const { currentUser } = useAuth();
  const [profile, setProfile] = useState<Partial<UserProfile>>({});
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  useEffect(() => {
    if (currentUser) {
      getUserProfile(currentUser.uid).then(data => {
        if (data) {
          setProfile(data);
          if (data.photoURL) {
            setImagePreview(data.photoURL);
          }
        }
      });
    }
  }, [currentUser]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    try {
      const updates = {
        ...profile,
        photoURL: imagePreview,
      };
      await updateUserProfile(currentUser.uid, updates);
      setMessage({ type: 'success', text: 'Profile updated successfully!' });
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to update profile' });
    }
  };

  return (
    <div className="space-y-6">
      {message.text && (
        <div className={`p-4 rounded-lg ${
          message.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
        }`}>
          {message.text}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Profile Image */}
        <div className="flex items-center space-x-6">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-[#2C2317] overflow-hidden">
              {imagePreview ? (
                <img 
                  src={imagePreview} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-3xl text-[#B38E3C]">
                  {profile.fullName?.[0]?.toUpperCase() || currentUser?.email?.[0]?.toUpperCase()}
                </div>
              )}
            </div>
            <label className="absolute bottom-0 right-0 p-1 bg-[#B38E3C] rounded-full cursor-pointer">
              <Camera size={16} />
              <input 
                type="file" 
                className="hidden" 
                accept="image/*"
                onChange={handleImageChange}
              />
            </label>
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-medium">Profile Photo</h3>
            <p className="text-sm text-gray-400">Update your profile picture</p>
          </div>
        </div>

        {/* Personal Information */}
        <div className="grid grid-cols-1 gap-6">
          <div>
            <label className="block text-sm font-medium text-white">Full Name</label>
            <input
              type="text"
              value={profile.fullName || ''}
              onChange={(e) => setProfile(prev => ({ ...prev, fullName: e.target.value }))}
              className="mt-1 block w-full rounded-md bg-[#2C2317] border-[#B38E3C] text-white"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-white">Username</label>
            <input
              type="text"
              value={profile.username || ''}
              onChange={(e) => setProfile(prev => ({ ...prev, username: e.target.value }))}
              className="mt-1 block w-full rounded-md bg-[#2C2317] border-[#B38E3C] text-white"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-white">Email</label>
            <input
              type="email"
              value={currentUser?.email || ''}
              className="mt-1 block w-full rounded-md bg-[#2C2317] border-[#B38E3C] text-white opacity-50"
              disabled
            />
            <p className="mt-1 text-sm text-gray-400">Email cannot be changed</p>
          </div>
        </div>

        <div className="flex justify-between items-center pt-6">
          <ActionButton
            type="button"
            variant="secondary"
            onClick={() => setShowDeleteModal(true)}
            className="!bg-red-900/20 text-red-500 hover:!bg-red-900/30"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Delete Account
          </ActionButton>

          <ActionButton type="submit" variant="primary">
            Save Changes
          </ActionButton>
        </div>
      </form>

      <DeleteAccountModal 
        isOpen={showDeleteModal} 
        onClose={() => setShowDeleteModal(false)} 
      />
    </div>
  );
}