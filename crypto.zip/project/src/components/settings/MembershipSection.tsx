import { useEffect, useState } from 'react';
import { Crown } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { getUserProfile } from '../../lib/firebase/db';
import { ActionButton } from '../ActionButton';
import { UpgradeVipModal } from './UpgradeVipModal';
import type { UserProfile } from '../../types/user';

export function MembershipSection() {
  const { currentUser } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  useEffect(() => {
    if (currentUser) {
      getUserProfile(currentUser.uid).then(setProfile);
    }
  }, [currentUser]);

  const vipLevels = [
    { level: 1, minDeposit: 50, maxDeposit: 500, earnings: '1%' },
    { level: 2, minDeposit: 501, maxDeposit: 1000, earnings: '1.5%' },
    { level: 3, minDeposit: 1001, maxDeposit: null, earnings: '2%' },
  ];

  const currentVipLevel = profile?.vipLevel || 1;
  const nextVipLevel = vipLevels.find(vip => vip.level > currentVipLevel);

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-[#2C2317] to-[#1A1512] rounded-xl p-6 border border-[#B38E3C]/20">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-xl font-semibold flex items-center gap-2">
              <Crown className="text-[#B38E3C]" />
              VIP Level {currentVipLevel}
            </h3>
            <p className="text-[#B38E3C] mt-1">
              {profile?.balance || 0} USDT Balance
            </p>
          </div>
          {nextVipLevel && (
            <ActionButton
              variant="primary"
              onClick={() => setShowUpgradeModal(true)}
            >
              Upgrade to VIP {nextVipLevel.level}
            </ActionButton>
          )}
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {vipLevels.map(({ level, minDeposit, maxDeposit, earnings }) => (
            <div
              key={level}
              className={`p-4 rounded-lg border ${
                level === currentVipLevel
                  ? 'border-[#B38E3C] bg-[#B38E3C]/10'
                  : 'border-gray-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold">VIP {level}</span>
                {level === currentVipLevel && (
                  <span className="text-xs bg-[#B38E3C] px-2 py-1 rounded">
                    Current
                  </span>
                )}
              </div>
              <ul className="space-y-2 text-sm">
                <li>Min Deposit: {minDeposit} USDT</li>
                <li>Max Deposit: {maxDeposit || 'Unlimited'} USDT</li>
                <li>Daily Earnings: {earnings}</li>
              </ul>
            </div>
          ))}
        </div>
      </div>

      <UpgradeVipModal
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        currentLevel={currentVipLevel}
        nextLevel={nextVipLevel!}
      />
    </div>
  );
}