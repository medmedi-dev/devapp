import React from 'react';

interface DashboardCardProps {
  title: string;
  value: string | number;
  icon?: React.ReactNode;
}

export function DashboardCard({ title, value, icon }: DashboardCardProps) {
  return (
    <div className="bg-gradient-to-br from-[#2C2317] to-[#1A1512] p-6 rounded-xl border border-[#B38E3C]/20">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[#B38E3C] text-sm font-medium">{title}</p>
          <p className="text-white text-2xl font-bold mt-2">{value}</p>
        </div>
        {icon && (
          <div className="text-[#B38E3C]">
            {icon}
          </div>
        )}
      </div>
    </div>
  );
}