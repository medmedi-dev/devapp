import React from 'react';
import { cn } from '../utils/cn';

interface ActionButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary';
  icon?: React.ReactNode;
}

export function ActionButton({ 
  children, 
  variant = 'primary', 
  icon,
  className,
  disabled,
  ...props 
}: ActionButtonProps) {
  return (
    <button
      className={cn(
        'flex items-center justify-center gap-2 px-6 py-3 rounded-lg font-medium transition-all',
        variant === 'primary' 
          ? 'bg-gradient-to-r from-[#B38E3C] to-[#DEB761] text-black hover:from-[#C69B43] hover:to-[#E5BE68]' 
          : 'bg-[#2C2317] text-[#B38E3C] hover:bg-[#382C1D]',
        disabled && 'opacity-50 cursor-not-allowed hover:from-[#B38E3C] hover:to-[#DEB761]',
        className
      )}
      disabled={disabled}
      {...props}
    >
      {icon && <span>{icon}</span>}
      {children}
    </button>
  );
}