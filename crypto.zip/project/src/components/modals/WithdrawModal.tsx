import { useState } from 'react';
import { Modal } from './Modal';
import { ActionButton } from '../ActionButton';
import { createTransaction } from '../../lib/firebase/db';
import { useAuth } from '../../contexts/AuthContext';

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  maxAmount: number;
}

export function WithdrawModal({ isOpen, onClose, maxAmount }: WithdrawModalProps) {
  const [amount, setAmount] = useState('');
  const [walletAddress, setWalletAddress] = useState('');
  const [error, setError] = useState('');
  const { currentUser } = useAuth();

  const MIN_WITHDRAWAL = 100;
  const isValidAmount = Number(amount) >= MIN_WITHDRAWAL && Number(amount) <= maxAmount;

  const validateWithdrawal = () => {
    const today = new Date();
    if (today.getDay() !== 0) {
      setError('Withdrawals are authorized only on Sundays. Please try again later.');
      return false;
    }

    if (!walletAddress.trim()) {
      setError('Please provide your wallet address.');
      return false;
    }

    if (!isValidAmount) {
      setError(`Withdrawal amount must be between ${MIN_WITHDRAWAL} and ${maxAmount} USDT`);
      return false;
    }

    return true;
  };

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (!validateWithdrawal()) return;

    try {
      await createTransaction({
        userId: currentUser.uid,
        type: 'withdrawal',
        amount: parseFloat(amount),
        status: 'pending',
        walletAddress,
        timestamp: new Date(),
      });
      onClose();
    } catch (error) {
      console.error('Error creating withdrawal:', error);
      setError('Failed to process withdrawal request');
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Withdraw USDT">
      <form onSubmit={handleWithdraw} className="space-y-4">
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
            {error}
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-white">Amount (USDT)</label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="mt-1 block w-full rounded-md bg-[#1A1512] border-[#B38E3C] text-white"
            min={MIN_WITHDRAWAL}
            max={maxAmount}
            step="0.01"
            required
          />
          <p className="text-sm text-[#B38E3C] mt-1">Available: {maxAmount} USDT</p>
        </div>

        <div>
          <label className="block text-sm font-medium text-white">USDT Wallet Address (TRC20)</label>
          <input
            type="text"
            value={walletAddress}
            onChange={(e) => setWalletAddress(e.target.value)}
            className="mt-1 block w-full rounded-md bg-[#1A1512] border-[#B38E3C] text-white"
            placeholder="Enter your TRC20 wallet address"
            required
          />
        </div>

        <div className="space-y-2 text-sm">
          <p className="text-[#B38E3C]">Important Notes:</p>
          <ul className="list-disc list-inside space-y-1 text-gray-300">
            <li>Minimum withdrawal amount is {MIN_WITHDRAWAL} USDT</li>
            <li>Withdrawals are only processed on Sundays</li>
            <li>Processing time: within 24 hours</li>
            <li>Make sure to enter the correct wallet address</li>
          </ul>
        </div>

        <div className="flex gap-4">
          <ActionButton
            type="button"
            variant="secondary"
            className="flex-1"
            onClick={onClose}
          >
            Cancel
          </ActionButton>
          <ActionButton
            type="submit"
            variant="primary"
            className="flex-1"
            disabled={!isValidAmount || !walletAddress.trim()}
          >
            Request Withdrawal
          </ActionButton>
        </div>
      </form>
    </Modal>
  );
}