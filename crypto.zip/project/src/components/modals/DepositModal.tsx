import { useState } from 'react';
import { Copy, QrCode } from 'lucide-react';
import { Modal } from './Modal';
import { ActionButton } from '../ActionButton';
import { createTransaction } from '../../lib/firebase/db';
import { useAuth } from '../../contexts/AuthContext';
import { cn } from '../../utils/cn';

const WALLET_ADDRESS = 'TC5DYmV3GWHJYeEPg2PY5512K2Z9whMBLT';
const MIN_DEPOSIT = 50;

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function DepositModal({ isOpen, onClose }: DepositModalProps) {
  const [amount, setAmount] = useState('');
  const [copied, setCopied] = useState(false);
  const { currentUser } = useAuth();

  const isValidAmount = Number(amount) >= MIN_DEPOSIT;

  const handleCopyAddress = async () => {
    try {
      await navigator.clipboard.writeText(WALLET_ADDRESS);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy address:', error);
    }
  };

  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !isValidAmount) return;

    try {
      await createTransaction({
        userId: currentUser.uid,
        type: 'deposit',
        amount: parseFloat(amount),
        status: 'pending',
        timestamp: new Date(),
      });
      onClose();
    } catch (error) {
      console.error('Error creating deposit:', error);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Deposit USDT">
      <form onSubmit={handleDeposit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-white mb-1">
            Enter Deposit Amount
          </label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder={`Enter amount (min: ${MIN_DEPOSIT} USDT)`}
            className={cn(
              'mt-1 block w-full rounded-md bg-[#1A1512] border-[#B38E3C] text-white',
              !isValidAmount && amount && 'border-red-500'
            )}
            min={MIN_DEPOSIT}
            step="0.01"
            required
          />
          {!isValidAmount && amount && (
            <p className="text-red-500 text-sm mt-1">
              Minimum deposit amount is {MIN_DEPOSIT} USDT
            </p>
          )}
        </div>
        <div className="space-y-4">
          <p className="text-sm text-[#B38E3C]">
            Send the desired amount to the following address:
          </p>
          <div className="bg-white p-4 rounded-lg w-48 h-48 mx-auto flex items-center justify-center">
            <QrCode size={160} />
          </div>
          <div className="bg-[#1A1512] p-3 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-[#B38E3C]">Address:</span>
              <button
                type="button"
                onClick={handleCopyAddress}
                className="text-sm text-[#B38E3C] hover:text-[#DEB761] flex items-center gap-1"
              >
                <Copy size={14} />
                {copied ? 'Copied!' : 'Copy'}
              </button>
            </div>
            <p className="text-sm break-all">{WALLET_ADDRESS}</p>
            <p className="text-sm text-[#B38E3C] mt-2">Network: Tron (TRC20)</p>
          </div>
        </div>
        <div className="flex gap-4">
          <ActionButton
            type="button"
            variant="secondary"
            className="flex-1"
            onClick={onClose}
          >
            Cancel
          </ActionButton>
          <ActionButton
            type="submit"
            variant="primary"
            className="flex-1"
            disabled={!isValidAmount}
          >
            Confirm Deposit
          </ActionButton>
        </div>
      </form>
    </Modal>
  );
}