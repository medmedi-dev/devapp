import { useState, useEffect } from 'react';
import { Modal } from './Modal';
import { subscribeToUserTransactions } from '../../lib/firebase/db';
import { useAuth } from '../../contexts/AuthContext';
import type { Transaction } from '../../types/user';

interface TransactionHistoryProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TransactionHistory({ isOpen, onClose }: TransactionHistoryProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const { currentUser } = useAuth();

  useEffect(() => {
    if (isOpen && currentUser) {
      const unsubscribe = subscribeToUserTransactions(currentUser.uid, setTransactions);
      return () => unsubscribe();
    }
  }, [isOpen, currentUser]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Transaction History">
      <div className="space-y-4">
        {transactions.map((tx) => (
          <div
            key={tx.id}
            className="flex items-center justify-between p-4 bg-[#1A1512] rounded-lg"
          >
            <div>
              <p className="font-medium">{tx.type === 'deposit' ? 'Deposit' : 'Withdrawal'}</p>
              <p className="text-sm text-[#B38E3C]">
                {new Date(tx.timestamp).toLocaleString()}
              </p>
            </div>
            <div>
              <p className={`font-bold ${tx.type === 'deposit' ? 'text-green-500' : 'text-red-500'}`}>
                {tx.type === 'deposit' ? '+' : '-'}{tx.amount} USDT
              </p>
              <p className={`text-sm text-right ${
                tx.status === 'approved' 
                  ? 'text-green-500' 
                  : tx.status === 'rejected'
                  ? 'text-red-500'
                  : 'text-yellow-500'
              }`}>
                {tx.status}
              </p>
            </div>
          </div>
        ))}
        {transactions.length === 0 && (
          <p className="text-center text-gray-400">No transactions found</p>
        )}
      </div>
    </Modal>
  );
}