import { initializeApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyCB8_u2xqNwbPaZciJ2LuHowdNjFGgVgI8",
  authDomain: "crypture-66a17.firebaseapp.com",
  projectId: "crypture-66a17",
  storageBucket: "crypture-66a17.firebasestorage.app",
  messagingSenderId: "348498115995",
  appId: "1:348498115995:web:b4a2254b9ede46d866f53e",
  measurementId: "G-GY77BSDZQZ"
};

// Initialize Firebase only if it hasn't been initialized yet
const app = !getApps().length ? initializeApp(firebaseConfig) : getApps()[0];
export const auth = getAuth(app);
export const db = getFirestore(app);