import { collection, doc, setDoc, getDoc, updateDoc, query, where, orderBy, getDocs, onSnapshot, Timestamp, runTransaction } from 'firebase/firestore';
import { db } from '../firebase';
import type { UserProfile, Transaction, Notification } from '../../types/user';

// User Profile Operations
export async function createUserProfile(uid: string, data: Partial<UserProfile>) {
  const userRef = doc(db, 'users', uid);
  await setDoc(userRef, {
    ...data,
    vipLevel: 1,
    balance: 0,
    totalRevenue: 0,
    todaysEarnings: 0,
    yesterdaysEarnings: 0,
    commissionToday: 0,
    createdAt: new Date(),
  });
}

export async function getUserProfile(uid: string) {
  const userRef = doc(db, 'users', uid);
  const userSnap = await getDoc(userRef);
  return userSnap.exists() ? userSnap.data() as UserProfile : null;
}

export async function updateUserProfile(uid: string, data: Partial<UserProfile>) {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, data);
}

export async function updateUserBalance(uid: string, amount: number) {
  try {
    await runTransaction(db, async (transaction) => {
      const userRef = doc(db, 'users', uid);
      const userDoc = await transaction.get(userRef);
      
      if (!userDoc.exists()) {
        throw new Error('User document does not exist!');
      }

      const userData = userDoc.data();
      const newBalance = (userData.balance || 0) + amount;
      const newTotalRevenue = (userData.totalRevenue || 0) + amount;

      transaction.update(userRef, { 
        balance: newBalance,
        totalRevenue: newTotalRevenue,
        lastUpdated: Timestamp.now()
      });
    });
  } catch (error) {
    console.error('Error updating user balance:', error);
    throw error;
  }
}

// Transaction Operations
export async function createTransaction(data: Omit<Transaction, 'id'>) {
  const transactionsRef = collection(db, 'transactions');
  const newTransactionRef = doc(transactionsRef);
  await setDoc(newTransactionRef, {
    ...data,
    id: newTransactionRef.id,
    timestamp: Timestamp.now(),
  });
  return newTransactionRef.id;
}

export function subscribeToUserTransactions(userId: string, callback: (transactions: Transaction[]) => void) {
  const q = query(
    collection(db, 'transactions'),
    where('userId', '==', userId)
  );
  
  return onSnapshot(q, (snapshot) => {
    const transactions = snapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
    })) as Transaction[];
    
    transactions.sort((a, b) => {
      const timestampA = (a.timestamp as any).toMillis?.() ?? 0;
      const timestampB = (b.timestamp as any).toMillis?.() ?? 0;
      return timestampB - timestampA;
    });
    
    callback(transactions);
  });
}

// Notifications
export async function createNotification(data: Omit<Notification, 'id'>) {
  const notificationsRef = collection(db, 'notifications');
  const newNotificationRef = doc(notificationsRef);
  await setDoc(newNotificationRef, {
    ...data,
    id: newNotificationRef.id,
    timestamp: Timestamp.now(),
    read: false,
  });
}

export function subscribeToUserNotifications(userId: string, callback: (notifications: Notification[]) => void) {
  const q = query(
    collection(db, 'notifications'),
    where('userId', '==', userId)
  );
  
  return onSnapshot(q, (snapshot) => {
    const notifications = snapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
    })) as Notification[];
    
    notifications.sort((a, b) => {
      const timestampA = (a.timestamp as any).toMillis?.() ?? 0;
      const timestampB = (b.timestamp as any).toMillis?.() ?? 0;
      return timestampB - timestampA;
    });
    
    callback(notifications);
  });
}

export async function markNotificationAsRead(notificationId: string) {
  const notificationRef = doc(db, 'notifications', notificationId);
  await updateDoc(notificationRef, { read: true });
}