import { collection, doc, setDoc, updateDoc, query, where, getDocs, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import type { WithdrawalRequest } from '../../types/withdrawal';

export async function createWithdrawalRequest(data: Omit<WithdrawalRequest, 'id' | 'status' | 'createdAt'>) {
  const withdrawalsRef = collection(db, 'withdrawalRequests');
  const newRequestRef = doc(withdrawalsRef);
  
  await setDoc(newRequestRef, {
    ...data,
    id: newRequestRef.id,
    status: 'pending',
    createdAt: new Date(),
  });
  
  return newRequestRef.id;
}

export async function updateWithdrawalStatus(
  requestId: string, 
  status: 'approved' | 'rejected',
  adminNote?: string
) {
  const requestRef = doc(db, 'withdrawalRequests', requestId);
  await updateDoc(requestRef, {
    status,
    adminNote,
    processedAt: new Date(),
  });
}

export function subscribeToWithdrawalRequests(
  userId: string,
  callback: (requests: WithdrawalRequest[]) => void
) {
  const q = query(
    collection(db, 'withdrawalRequests'),
    where('userId', '==', userId)
  );
  
  return onSnapshot(q, (snapshot) => {
    const requests = snapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
    })) as WithdrawalRequest[];
    callback(requests);
  });
}

export function subscribeToAllWithdrawalRequests(
  callback: (requests: WithdrawalRequest[]) => void
) {
  const q = query(collection(db, 'withdrawalRequests'));
  
  return onSnapshot(q, (snapshot) => {
    const requests = snapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
    })) as WithdrawalRequest[];
    callback(requests);
  });
}