import { doc, getDoc, setDoc, collection, query, getDocs, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import type { UserProfile } from '../../types/user';

export async function isAdmin(uid: string): Promise<boolean> {
  const userRef = doc(db, 'users', uid);
  const userSnap = await getDoc(userRef);
  
  if (!userSnap.exists()) {
    // If user document doesn't exist, create it with admin role
    await setDoc(userRef, {
      uid,
      email: 'admin@gmail.com',
      role: 'admin',
      fullName: 'Admin User',
      username: 'admin',
      vipLevel: 3,
      balance: 0,
      totalRevenue: 0,
      todaysEarnings: 0,
      yesterdaysEarnings: 0,
      commissionToday: 0,
      createdAt: new Date()
    });
    return true;
  }
  
  return userSnap.data()?.role === 'admin';
}

export async function getAllUsers(): Promise<UserProfile[]> {
  const usersRef = collection(db, 'users');
  const snapshot = await getDocs(query(usersRef));
  return snapshot.docs.map(doc => ({ ...doc.data(), uid: doc.id }) as UserProfile);
}

export async function updateUserStatus(uid: string, updates: Partial<UserProfile>) {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, updates);
}