import { collection, getDocs, doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';

// Fetch all deposit requests from the 'deposits' collection
export async function getAllDepositRequests() {
  try {
    const depositsRef = collection(db, 'deposits');
    const depositDocs = await getDocs(depositsRef);
    return depositDocs.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Failed to fetch deposit requests:', error);
    throw error;
  }
}

// Update the status of a specific deposit request
export async function updateDepositStatus(id: string, status: string) {
  try {
    const depositRef = doc(db, 'deposits', id);
    await updateDoc(depositRef, { status });
  } catch (error) {
    console.error('Failed to update deposit status:', error);
    throw error;
  }
}
