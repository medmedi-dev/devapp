import { doc, setDoc, updateDoc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import type { UserEarnings } from '../../types/withdrawal';

const VIP_RATES = {
  1: 0.01, // 1%
  2: 0.015, // 1.5%
  3: 0.02, // 2%
};

export async function initializeUserEarnings(userId: string, vipLevel: number) {
  const earningsRef = doc(db, 'userEarnings', userId);
  await setDoc(earningsRef, {
    userId,
    vipLevel,
    dailyRate: VIP_RATES[vipLevel as keyof typeof VIP_RATES],
    lastUpdate: new Date(),
    totalEarnings: 0,
    tradingDays: 0,
  });
}

export async function updateUserEarnings(userId: string) {
  const earningsRef = doc(db, 'userEarnings', userId);
  const userRef = doc(db, 'users', userId);
  
  const [earningsDoc, userDoc] = await Promise.all([
    getDoc(earningsRef),
    getDoc(userRef)
  ]);
  
  if (!earningsDoc.exists() || !userDoc.exists()) return;
  
  const earnings = earningsDoc.data() as UserEarnings;
  const user = userDoc.data();
  const now = new Date();
  const lastUpdate = earnings.lastUpdate.toDate();
  
  // Calculate days since last update
  const daysDiff = Math.floor((now.getTime() - lastUpdate.getTime()) / (1000 * 60 * 60 * 24));
  
  if (daysDiff > 0) {
    const dailyEarning = user.balance * earnings.dailyRate;
    const newEarnings = dailyEarning * daysDiff;
    
    // Update user balance and earnings
    await Promise.all([
      updateDoc(userRef, {
        balance: user.balance + newEarnings,
        totalRevenue: user.totalRevenue + newEarnings,
        todaysEarnings: dailyEarning,
        yesterdaysEarnings: user.todaysEarnings || 0,
      }),
      updateDoc(earningsRef, {
        lastUpdate: now,
        totalEarnings: earnings.totalEarnings + newEarnings,
        tradingDays: earnings.tradingDays + daysDiff,
      })
    ]);
  }
}