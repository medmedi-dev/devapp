export interface WithdrawalRequest {
  id: string;
  userId: string;
  amount: number;
  walletAddress: string;
  status: 'pending' | 'approved' | 'rejected';
  adminNote?: string;
  createdAt: Date;
  processedAt?: Date;
}

export interface UserEarnings {
  userId: string;
  vipLevel: number;
  dailyRate: number;
  lastUpdate: Date;
  totalEarnings: number;
  tradingDays: number;
}