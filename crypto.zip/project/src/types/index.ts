export interface User {
  id: string;
  username: string;
  vipLevel: number;
  totalBalance: number;
  totalRevenue: number;
  todaysEarnings: number;
  yesterdaysEarnings: number;
  commissionToday: number;
}

export interface WalletTransaction {
  id: string;
  type: 'deposit' | 'withdrawal';
  amount: number;
  timestamp: Date;
  status: 'pending' | 'completed' | 'failed';
  currency: string;
}