export interface UserProfile {
  uid: string;
  fullName: string;
  username: string;
  email: string;
  photoURL?: string;
  vipLevel: number;
  balance: number;
  totalRevenue: number;
  todaysEarnings: number;
  yesterdaysEarnings: number;
  commissionToday: number;
  createdAt: Date;
}

export interface Transaction {
  id: string;
  userId: string;
  type: 'deposit' | 'withdrawal';
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  walletAddress?: string;
  timestamp: Date;
  adminNote?: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'transaction' | 'system';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  transactionId?: string;
}